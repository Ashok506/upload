<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">

<link rel="stylesheet" href="css/bootstrap.min.css">

<html>



<head>
<style>.guidebox{ display:none;}

.modal-form input[name=email] {
  border-bottom:2px solid #5DBDAB !important;
  border-top:none !important;
  border-left:none !important;
  border-right:none !important;
  color:#000 !important;
  margin:4% 0 0 0% !important;
 }
 .modal-form input[name=mobile] {
  border-bottom:2px solid #5DBDAB !important;
  border-top:none !important;
  border-left:none !important;
  border-right:none !important;
  color:#000 !important;
  margin:4% 0 4% 0% !important;
  
  
 }
 .modal-form input[type=submit] {
  
      display: block !important;
    
    border: 0 !important;
    padding: 7px 15px !important;
    border-radius: 6px!important;
    font-family: nexabold!important;
    font-size: 17px!important;
    background-color: #5DBDAB!important;
    color: #FFFFFF!important;
	outline:none!important;
	margin: 0 auto !important;
  
 }
.modal-form form label{
color:#000!important;
font-size:20px!important;
font-family:sans-serif!important;
text-transform:uppercase!important;	
width:29%!important; 
float:left!important; 
font-size:15px!important;
margin:5% 0% 0 5%!important;
outline:none!important;
font-weight:bold!important;
text-align:left !important;

}
.form-class{ width:100%!important; margin:0 auto!important; border:3px  dashed #F47B5C!important; border-radius:10px!important;}
.sdfg{ float: left; margin: 0px 0 20px 25px; width:100%;font-family: sans-serif; font-weight:bold;}
.type{  width: 4%; margin-bottom:10%;}

</style>
<script type='text/javascript' src='http://local.adfender.com/adfender/elemhide.js'></script>

<!-- Metatags & Description & Titles adding into dynamically at all pages -->



  <meta http-equiv="content-type" content="text/html; charset=utf-8" />

  

   <meta http-equiv="X-UA-Compatible" content="IE=8" />

  

  <meta http-equiv="X-UA-Compatible" content="IE=9" />



  <meta name="google-site-verification" content="google3552560da7870e25" />



  <meta name="keywords" content="detox program, health detox, diet plan for detoxification, 1-day detox, Detoxify The Body, 3-day detox, Nourish Pack, Favourites Pack, Cleanse, Cleanse High, health, super foods,raw, cold pressed, organic greens, fresh vegetables" />



  <meta name="rights" content="CleanseHigh.com" />



  <meta name="robots" content="index, follow" />



  <meta name="description" content="Choose from a range of 1 day, 3 day, Nourish Pack, or create your own set of favorite juices. Each regime is designed to kick-start process of cleansing and detoxification.        " />





<meta name="viewport" content="width=device-width, initial-scale=1.0">



  <title> Cleansehigh | Order </title>

  

  <link rel="image_src" href="http://cleansehigh.com/images/buddy-high.png" / >



<!-- Metatags & Description & Titles adding into dynamically at all pages -->



<link rel="icon" type="image/x-icon" href="http://www.cleansehigh.com/images/favicon.png">



<link href="css/styles.css" rel="stylesheet" type="text/css">







<link href="css/style_tab.css" rel="stylesheet" type="text/css">







<script src="js/jquery.js" type="text/javascript"></script>







<script language="javascript" src="js/regimes/main.js"></script>







<script language="javascript" src="js/regimes/modernizr.js"></script>







<!--<script language="javascript" src="js/regimes/jquery-2.1.1.js"></script>-->



<script src="js/jquery.min_1.8.1.js" type="text/javascript"></script>



<!-- Daily first time open pop -->

<!--<script src="js/jquery/daily_first_time_popup.js" type="text/javascript"></script>-->

<!-- Daily first time open pop END-->



<script>



  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){



  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),



  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)



  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');







  ga('create', 'UA-42133965-1', 'auto');



  ga('require', 'displayfeatures'); //To enable Display Advertising features for Universal Analytics



  ga('send', 'pageview');







</script>



<!-- Facebook Conversion Code for Firdous -->

<script>(function() {

var _fbq = window._fbq || (window._fbq = []);

if (!_fbq.loaded) {

var fbds = document.createElement('script');

fbds.async = true;

fbds.src = '//connect.facebook.net/en_US/fbds.js';

var s = document.getElementsByTagName('script')[0];

s.parentNode.insertBefore(fbds, s);

_fbq.loaded = true;

}

})();

window._fbq = window._fbq || [];

window._fbq.push(['track', '6022602197244', {'value':'0.01','currency':'INR'}]);

</script>

<noscript><img height="1" width="1" alt="" style="display:none" src="https://www.facebook.com/tr?ev=6022602197244&amp;cd[value]=0.01&amp;cd[currency]=INR&amp;noscript=1" /></noscript>



<script>(function() {

  var _fbq = window._fbq || (window._fbq = []);

  if (!_fbq.loaded) {

    var fbds = document.createElement('script');

    fbds.async = true;

    fbds.src = '//connect.facebook.net/en_US/fbds.js';

    var s = document.getElementsByTagName('script')[0];

    s.parentNode.insertBefore(fbds, s);

    _fbq.loaded = true;

  }

  _fbq.push(['addPixelId', '365635786941931']);

})();

window._fbq = window._fbq || [];

window._fbq.push(['track', 'PixelInitialized', {}]);

</script>

<noscript><img height="1" width="1" alt="" style="display:none" src="https://www.facebook.com/tr?id=365635786941931&amp;ev=PixelInitialized" /></noscript>



<link href="css/responsive.css" rel="stylesheet" type="text/css">



</head>



<body>



<div class="wrapper">

<header>

<div class="header-authentication txt-rt">





</div>



<?php include "includes/nav.php" ?>



</header>

<!-- All Cms and home page block  -->

<div class="wrap pull-left wrap1">



<!-------------------------------->
<div>
<div class="content-lte" style="width:36%; float:left;     margin: 0 0 0 10%;">
<?php 
$action= isset($_REQUEST['action']); 
if ($action=="")    
    { 
    ?>
    <div class="modal-form" style="width:100%;"> 
	<form method="post" enctype="multipart/form-data" class="form-class" action="" onSubmit="return validation()">

    <input type="hidden" name="action" value="submit"> 
    <label>USER E-Mail  </label>  
    <input name="email" type="text" id="email"/><br>

 
   <label> MOBILE NUMBER  </label>
    <input name="mobile" type="text" id="mobile"  style="margin:0;"/ ><br>
   <label class="sdfg"> REGIME </label><br />

    <input type="radio" name="regime" value="seeker" class="type" /> SEEKER
    <input type="radio" name="regime" value="sage" class="type" /> SAGE
    <input type="radio" name="regime" value="nirvana"  class="type"/> NIRVANA <br>
    <label>SUMMARY </label><br> 
    <textarea name="summary" id="summary" rows="7" cols="40" style="border:2px solid  #5DBDAB ;outline:none;"></textarea><br> <br>
    <input  type="submit" value="SUBMIT"/>  <br>   </form> 
    </div>
    <?php 
    }  
else                
    { 
	
	$mobile = $_REQUEST['mobile'];
	$regime = $_REQUEST['regime'];
	$summary = $_REQUEST['summary'];
	
$to = "detox@cleansehigh.com";
$subject = "Order";
$mn = $mobile;
$headers = $regime;

        mail($to, "Regime:" . $headers, $mn , $summary); 
        echo "Email sent!"; 
    }   
?>

</div>

<div class="contentsd">



    <div class="guidebox">

	    <h1 class="txt-cr"> <span> ORDER </span> </h1>

    </div>

<div class="contentsd" style="text-align:right;">

	<img width="475" border="0" height="335" class="ordryui" alt="reach us 8008698686" src="images/CONTACT-1.png">

</div>

<div class="ordrtyuio" style="text-align: center;margin-top: -225px; margin-left: 0px;">

<!--<span style="text-align:right; font-size: 14px;">Please place your order 48 hours in advance of your start date.<br>Within 24 hours, please call for availability</span>--> <br><br><br><br><br> 

<!--<a href="#">

<button type="submit" class="validate mg-left dlvruy-log" style="margin-left: -5%; margin-top: -4%; margin-top: -4%; outline:0px;">

<h2 style="font-size: 20px;padding:20px 0px;margin:0px;">DELIVERY LOGISTICS</h2>

</button></a>-->

</div>



   



</div> 
</div><!--parent-->
<!--<h4 class="dlvruy-logsdf" style="margin: -55px 0 0 180px;">Serving Hyderabad</h4>-->



</div>



<?php include "includes/footer.php" ?>

  





</div>

<!-- All Cms and home page block  -->



<!-- MIDDLE CONTENT END -->  



<script type="text/javascript">



jQuery(function(){



// The height of the content block when it's not expanded



var adjustheight = 140;



// The "more" link text



var moreText = "Read More...";



// The "less" link text



var lessText = "Read Less...";







// Sets the .more-block div to the specified height and hides any content that overflows



jQuery(".more-less .more-block").css('height', adjustheight).css('overflow', 'hidden').css('margin-bottom','20px');







// The section added to the bottom of the "more-less" div



//$(".more-less").append('<p class="continued">[&hellip;]</p><a href="#" class="adjust"></a>');







jQuery(".more-less").append('<a href="#" class="adjust continued"></a>');







jQuery("a.adjust").text(moreText);







jQuery(".adjust").toggle(function() {



		jQuery(this).parents("div:first").find(".more-block").css('height', 'auto').css('overflow', 'visible');



		// Hide the [...] when expanded



		jQuery(this).parents("div:first").find("p.continued").css('display', 'none');



		jQuery(this).text(lessText);



	}, function() {



		jQuery(this).parents("div:first").find(".more-block").css('height', adjustheight).css('overflow', 'hidden');



		jQuery(this).parents("div:first").find("p.continued").css('display', 'block');



		jQuery(this).text(moreText);



});



});







</script>



 <!-- Instragram Recent Posted Pictures Dispalying Block -->

		<!-- Instragram Recent Posted Pictures Dispalying Block END -->		





        

	

         <div class="clear"> </div>

</div>



	

</body>

</html>