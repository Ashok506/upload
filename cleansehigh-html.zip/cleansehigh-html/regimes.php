<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<link rel="stylesheet" href="css/bootstrap.min.css">
<html>
<head>
<!-- AdFender script begin -->
<script type='text/javascript' src='http://local.adfender.com/adfender/elemhide.js'></script>
<!-- AdFender script end -->
<!-- Metatags & Description & Titles adding into dynamically at all pages -->
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=8" />
<meta http-equiv="X-UA-Compatible" content="IE=9" />
<meta name="google-site-verification" content="google3552560da7870e25" />
<meta name="keywords" content="detox program, health detox, diet plan for detoxification, 1-day detox, Detoxify The Body, 3-day detox, Nourish Pack, Favourites Pack, Cleanse, Cleanse High, health, super foods,raw, cold pressed, organic greens, fresh vegetables" />
<meta name="rights" content="CleanseHigh.com" />
<meta name="robots" content="index, follow" />
<meta name="description" content="Choose your detox diet plan from a range of 1 day, 3 day, 6 day, or create your own set of favorite detox juices. Each detox regime is designed to kick-start process of cleansing and detoxification. - CleanseHigh India" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Detox Diet Plan : Seeker, Sage, Nirvana Regimes from CleanseHigh India</title>
<link rel="image_src" href="http://cleansehigh.com/images/buddy-high.png" / >
<!-- Metatags & Description & Titles adding into dynamically at all pages -->
<link rel="icon" type="image/x-icon" href="http://www.cleansehigh.com/images/favicon.png">
<link href="css/styles.css" rel="stylesheet" type="text/css">
<link href="css/style_tab.css" rel="stylesheet" type="text/css">
<script src="js/jquery.js" type="text/javascript"></script>
<script language="javascript" src="js/regimes/main.js"></script>
<script language="javascript" src="js/regimes/modernizr.js"></script>
<!--<script language="javascript" src="js/regimes/jquery-2.1.1.js"></script>-->
<script src="js/jquery.min_1.8.1.js" type="text/javascript"></script>
<!-- Daily first time open pop -->
<!--<script src="js/jquery/daily_first_time_popup.js" type="text/javascript"></script>-->
<!-- Daily first time open pop END-->
<script>



  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){



  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),



  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)



  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');







  ga('create', 'UA-42133965-1', 'auto');



  ga('require', 'displayfeatures'); //To enable Display Advertising features for Universal Analytics



  ga('send', 'pageview');







</script>
<!-- Facebook Conversion Code for Firdous -->
<script>(function() {

var _fbq = window._fbq || (window._fbq = []);

if (!_fbq.loaded) {

var fbds = document.createElement('script');

fbds.async = true;

fbds.src = '//connect.facebook.net/en_US/fbds.js';

var s = document.getElementsByTagName('script')[0];

s.parentNode.insertBefore(fbds, s);

_fbq.loaded = true;

}

})();

window._fbq = window._fbq || [];

window._fbq.push(['track', '6022602197244', {'value':'0.01','currency':'INR'}]);

</script>
<noscript>
<img height="1" width="1" alt="" style="display:none" src="https://www.facebook.com/tr?ev=6022602197244&amp;cd[value]=0.01&amp;cd[currency]=INR&amp;noscript=1" />
</noscript>
<script>(function() {

  var _fbq = window._fbq || (window._fbq = []);

  if (!_fbq.loaded) {

    var fbds = document.createElement('script');

    fbds.async = true;

    fbds.src = '//connect.facebook.net/en_US/fbds.js';

    var s = document.getElementsByTagName('script')[0];

    s.parentNode.insertBefore(fbds, s);

    _fbq.loaded = true;

  }

  _fbq.push(['addPixelId', '365635786941931']);

})();

window._fbq = window._fbq || [];

window._fbq.push(['track', 'PixelInitialized', {}]);

</script>
<noscript>
<img height="1" width="1" alt="" style="display:none" src="https://www.facebook.com/tr?id=365635786941931&amp;ev=PixelInitialized" />
</noscript>
<style>

.cd-tabs nav{

	width:40%;

	}

</style>
<link href="css/responsive.css" rel="stylesheet" type="text/css">
<!-- Chatra {literal} added on 13-6-2016-->
<script>
    ChatraID = 'yAYypgmkj8RiRdzJ3';
    (function(d, w, c) {
        var n = d.getElementsByTagName('script')[0],
            s = d.createElement('script');
        w[c] = w[c] || function() {
            (w[c].q = w[c].q || []).push(arguments);
        };
        s.async = true;
        s.src = (d.location.protocol === 'https:' ? 'https:': 'http:')
            + '//call.chatra.io/chatra.js';
        n.parentNode.insertBefore(s, n);
    })(document, window, 'Chatra');
</script>
<!-- /Chatra {/literal} added on 13-6-2016-->
<script>
window.ChatraSetup = {
    colors: [
        '#fff', // text color
        '#5DBDAB'  // background color
    ]
};
</script>
</head><body>
<div class="wrapper">
  <!-- Top Header -->
  <header>
    <div class="header-authentication txt-rt"> </div>
    <?php include "includes/nav.php" ?>
  </header>
  <!-- All Cms and home page block  -->
  <div class="wrap pull-left wrap1 wrap2">
    <div class="page-content pull-left txt-lt">
      <div class="cd-tabs">
        <nav>
          <ul class="cd-tabs-navigation">
            <li><a href="#0" class="selected" data-content="3-days">SEEKER<span>1 Day</span></a></li>
            <li><a href="#0" data-content="1-day">SAGE<span style="margin-left: -26px;">3 Days</span></a></li>
            <li><a href="#0" data-content="Favourites">NIRVANA<span>6 Days</span></a></li>
          </ul>
          <br />
          <br />
          <br />
          <br />
          <!-- cd-tabs-navigation -->
        </nav>
        <ul id="rgmsccd" class="cd-tabs-content">
          <!-- Dispalying 3 days Block -->
          <li class="selected" data-content="3-days"> <span class="actvf">1 Day</span>
            <p></p>
            <p id="hdng" class="blog-head" style="font-size:18px; font-family: HeadingFont1 !important;">Perfect for the "never ever skipped a meal in my whole life" kind of a person.</p>
            <p id="prstyui" class="prsat prsat-cnt"> A day-long detox, every week as a means of purification and self-discipline, stretches way back in time of Yogis, to cleanse ad thus rejuvenate the body. We recommend this to anyone joining the first detox ever band wagon, or even just as a weekly cleansing routine. It goes down easy and is alkalizing & refreshing.</p>
            <p class="cntry"><img src="images/1day-plan.png" alt="one day plan" /> </p>
          </li>
          <!-- Dispalying 3 days Block END -->
          <!-- Dispalying 1 day Block -->
          <li data-content="1-day"> <span class="actvf1">3 Days</span>
            <p id="hdng" class="blog-head" style="font-size:18px; font-family: HeadingFont1 !important;">A ritual of deep rejuvenation to feel new.</p>
            <!--<p>During this extended fast, your body removes: dead, dying and diseased cells; unwanted fatty tissue, acids, toxic waste matter in the lymphatic system, bloodstream, spleen, liver and kidney.</p>

<p style="text-transform:uppercase;color:#f68d1e;">It simply breaks down all the bad stuff and flushes it out of your body. </p>

-->
            <p class="prsat prsat-cnt">At the end of this regime you will discover mental clarity, experience boosted energy, cleaner organs and realize what it feels like to feel good from inside! </p>
            <p class="cntry"><img src="images/3day-plan.png" alt="three day plan" /> </p>
          </li>
          <!-- Dispalying 1 day Block END -->
          <!-- Dispalying Paleo Block  -->
          <!-- Dispalying Paleo Block END -->
          <!-- Dispalying  Favourites  -->
          <li data-content="Favourites"> <span class="actvf2">6 Days</span>
            <p id="hdng" class="blog-head" style="font-size:18px; font-family: HeadingFont1 !important;">A holistic reboot with nourishing tonics and a guided food plan.</p>
            <p class="prsat prsat-cnt">During this extended fast, your body removes: dead, dying and diseased cells; unwanted fatty tissue, acids, toxic waste matter in the lymphatic system, bloodstream, spleen, liver and kidney.</p>
            <p class="prsat prsat-cnt"> A perfect teamwork of liquids & solid foods to promote a stronger immune system. Nourish with just the right foods.</p>
            <p style="color: #EEA600; font-family: monospace; font-size: 18px; text-align: center;"> A 360-DEGREE NOURISHING REGIME. </p>
            <!--<p> A perfect teamwork of liquids & solid foods to promote a stronger immune system. Nourish with just the right foods. A perfect meal plan to adopt for a couple of days: </p>



<span class="sub-icon"> </span> <span class="sub-para">Prior to your BiG Day</span><br />

<span class="sub-icon"> </span> <span class="sub-para">It is a sesible plan for Weight Loss</span><br />

<span class="sub-icon"> </span> <span class="sub-para">Post Overindulgence from festive foods.</span><br />

<span class="sub-icon"> </span> <span class="sub-para">Just feel good & look good.</span><br />-->
            <!--<p>You can order any of your favourites juices to make a pack of 6. <br> Its' great for families, for the office, or even just for you (why share?).</p>

        <p> 

            <span class="sub-icon"> </span>

            <span class="sub-para">Perfect for</span> <br> 		 		 		

            <span class="favs">Tea Parties. </span> 		

            <span class="favs">Power foods for your road trip.</span> 		

            <span class="favs">  Post-Surgical recovery. </span> 		

            <span class="favs">  Nourishing snack for growing kids. </span>

        </p>-->
            <p>&nbsp;</p>
          </li>
          <!-- Dispalying Favourites END -->
          <!-- cd-tabs-content -->
        </ul>
      </div>
    </div>
    <div class="clear"> </div>
  </div>
  <!-- All Cms and home page block  -->
  <!-- MIDDLE CONTENT END -->
  <script type="text/javascript">



jQuery(function(){



// The height of the content block when it's not expanded



var adjustheight = 140;



// The "more" link text



var moreText = "Read More...";



// The "less" link text



var lessText = "Read Less...";







// Sets the .more-block div to the specified height and hides any content that overflows



jQuery(".more-less .more-block").css('height', adjustheight).css('overflow', 'hidden').css('margin-bottom','20px');







// The section added to the bottom of the "more-less" div



//$(".more-less").append('<p class="continued">[&hellip;]</p><a href="#" class="adjust"></a>');







jQuery(".more-less").append('<a href="#" class="adjust continued"></a>');







jQuery("a.adjust").text(moreText);







jQuery(".adjust").toggle(function() {



		jQuery(this).parents("div:first").find(".more-block").css('height', 'auto').css('overflow', 'visible');



		// Hide the [...] when expanded



		jQuery(this).parents("div:first").find("p.continued").css('display', 'none');



		jQuery(this).text(lessText);



	}, function() {



		jQuery(this).parents("div:first").find(".more-block").css('height', adjustheight).css('overflow', 'hidden');



		jQuery(this).parents("div:first").find("p.continued").css('display', 'block');



		jQuery(this).text(moreText);



});



});







</script>
  <!-- Instragram Recent Posted Pictures Dispalying Block -->
  <!-- Instragram Recent Posted Pictures Dispalying Block END -->
  <?php include "includes/footer.php" ?>
  <div class="clear"> </div>
</div>
</body>
</html>