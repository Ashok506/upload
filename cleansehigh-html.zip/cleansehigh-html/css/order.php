<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">

<link rel="stylesheet" href="css/bootstrap.min.css">

<html>



<head>

<style>


body {
 
}

form header {
  margin: 0 0 20px 0; 
}
form header div {
  font-size: 90%;
  color: #999;
}
form header h2 {
  margin: 0 0 5px 0;
}
form > div {
  clear: both;
  overflow: hidden;
  padding: 1px;
  margin: 0 0 10px 0;
}
form > div > fieldset > div > div {
  margin: 0 0 5px 0;
}
form > div > label,
legend {
	width: 20%;
  float: left;
  padding-right: 10px;
}
form > div > div,
form > div > fieldset > div {
  width: 78%;
  float: right;
}
form > div > fieldset label {
	font-size: 90%;
}
fieldset {
	border: 0;
  padding: 0;
  text-align:left;
}

input[type=text],
input[type=email],
input[type=url],
input[type=password],
textarea {
	width: 40%;
  border:none;
  border-bottom: 2px solid #5DBDAB !important;
  float:left;
  margin-left:20px;
}
input[type=text],
input[type=email],
input[type=url],
input[type=password] {
  width: 40%;
  letter-spacing:1px;
  float:left;
  margin-left:20px;
  color:#333;
  font-weight:normal;
}
input[type=text]:focus,
input[type=email]:focus,
input[type=url]:focus,
input[type=password]:focus,
textarea:focus {
  outline: 0;
  border-color: #4697e4;
}

@media (max-width: 600px) {
  form > div {
    margin: 0 0 15px 0; 
	text-align:center;
  }
  form > div > label,
  legend {
	  width: 100%;
    float: none;
    margin: 0 0 5px 0;
  }
  form > div > div,
  form > div > fieldset > div {
    width: 100%;
    float: none;
  }
  input[type=text],
  input[type=email],
  input[type=url],
  input[type=password],
  textarea,
  select {
    width: 100%; 
  }
}
@media (min-width: 1200px) {
  form > div > label,
	legend {
  	text-align: right;
  }
}
.order-form input[type=submit]{
	text-transform:uppercase;
	display: block !important;
    border: 0 !important;
	margin:20px auto !important;
    padding: 10px 15px !important;
    border-radius: 6px!important;
    font-family:cambria;
    font-size: 17px!important;
    background-color: #5DBDAB!important;
    color: #FFFFFF!important;
    outline: none!important;
	 letter-spacing:1px;
	font-size:13px;
   }
 .order-form input[type=submit]:hover{cursor:pointer;}
form.order-form label, legend  {text-transform:uppercase;text-align:left;font-family:cambria;font-size:13px; letter-spacing:1px;}
legend {    padding: 0 !important;
    margin-bottom: 0px !important;line-height: inherit;
    color: #333; 
    border:none !important;}
.form-container {float:left;width:600px; height:auto; margin-left:5%;}
.messagesent {width: 50%; height: 30px;font-size: 15px;position: absolute;border-radius: 5px;
    border: 1px dashed #5DBDAB;
    top: 3%;
    left: 0;
    right: 0;
    bottom: 0;
    color: #5DBDAB;
    font-size: 20px;
    margin: 0 auto;}
</style>
<script type='text/javascript' src='http://local.adfender.com/adfender/elemhide.js'></script>

<!-- Metatags & Description & Titles adding into dynamically at all pages -->



  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
   <meta http-equiv="X-UA-Compatible" content="IE=8" />
  <meta http-equiv="X-UA-Compatible" content="IE=9" />
  <meta name="google-site-verification" content="google3552560da7870e25" />
  <meta name="keywords" content="detox program, health detox, diet plan for detoxification, 1-day detox, Detoxify The Body, 3-day detox, Nourish Pack, Favourites Pack, Cleanse, Cleanse High, health, super foods,raw, cold pressed, organic greens, fresh vegetables" />
  <meta name="rights" content="CleanseHigh.com" />
  <meta name="robots" content="index, follow" />
  <meta name="description" content="Choose from a range of 1 day, 3 day, Nourish Pack, or create your own set of favorite juices. Each regime is designed to kick-start process of cleansing and detoxification.        " />
<meta name="viewport" content="width=device-width, initial-scale=1.0">

  <title> Cleansehigh | Order </title>

  <link rel="image_src" href="http://cleansehigh.com/images/buddy-high.png" / >



<!-- Metatags & Description & Titles adding into dynamically at all pages -->



<link rel="icon" type="image/x-icon" href="http://www.cleansehigh.com/images/favicon.png">

<link href="css/styles.css" rel="stylesheet" type="text/css">

<link href="css/style_tab.css" rel="stylesheet" type="text/css">

<script src="js/jquery.js" type="text/javascript"></script>

<script language="javascript" src="js/regimes/main.js"></script>

<script language="javascript" src="js/regimes/modernizr.js"></script>

<!--<script language="javascript" src="js/regimes/jquery-2.1.1.js"></script>-->



<script src="js/jquery.min_1.8.1.js" type="text/javascript"></script>



<!-- Daily first time open pop -->

<!--<script src="js/jquery/daily_first_time_popup.js" type="text/javascript"></script>-->

<!-- Daily first time open pop END-->



<script>



  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){



  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),



  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)



  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');







  ga('create', 'UA-42133965-1', 'auto');



  ga('require', 'displayfeatures'); //To enable Display Advertising features for Universal Analytics



  ga('send', 'pageview');







</script>



<!-- Facebook Conversion Code for Firdous -->

<script>(function() {

var _fbq = window._fbq || (window._fbq = []);

if (!_fbq.loaded) {

var fbds = document.createElement('script');

fbds.async = true;

fbds.src = '//connect.facebook.net/en_US/fbds.js';

var s = document.getElementsByTagName('script')[0];

s.parentNode.insertBefore(fbds, s);

_fbq.loaded = true;

}

})();

window._fbq = window._fbq || [];

window._fbq.push(['track', '6022602197244', {'value':'0.01','currency':'INR'}]);

</script>

<noscript><img height="1" width="1" alt="" style="display:none" src="https://www.facebook.com/tr?ev=6022602197244&amp;cd[value]=0.01&amp;cd[currency]=INR&amp;noscript=1" /></noscript>



<script>(function() {

  var _fbq = window._fbq || (window._fbq = []);

  if (!_fbq.loaded) {

    var fbds = document.createElement('script');

    fbds.async = true;

    fbds.src = '//connect.facebook.net/en_US/fbds.js';

    var s = document.getElementsByTagName('script')[0];

    s.parentNode.insertBefore(fbds, s);

    _fbq.loaded = true;

  }

  _fbq.push(['addPixelId', '365635786941931']);

})();

window._fbq = window._fbq || [];

window._fbq.push(['track', 'PixelInitialized', {}]);

</script>

<noscript><img height="1" width="1" alt="" style="display:none" src="https://www.facebook.com/tr?id=365635786941931&amp;ev=PixelInitialized" /></noscript>



<link href="css/responsive.css" rel="stylesheet" type="text/css">



</head>



<body>



<div class="wrapper">

<header>

<div class="header-authentication txt-rt">
</div>



<?php include "includes/nav.php" ?>



</header>

<!-- All Cms and home page block  -->

<div class="wrap pull-left wrap1">


<?php 
if(isset($_POST['submit'])){
    $to = "detox@cleansehigh.com"; // this is your Email address
    $from = $_POST['email']; // this is the sender's Email address
    $first_name = $_POST['first_name'];
    $email = $_POST['email'];
    $mobile_number = $_POST['mobile_number'];
	$regime = $_POST['regime'];
	$summary = $_POST['message'];
    $subject = $email;
    $message = "\n REGIME: " . $regime . "\n\n NAME: " . $first_name . "\n\n EMAIL: " . $email . "\n\n MESSAGE: " . $summary . "\n\n MOBILE: " .$mobile_number;

    $headers = "From:" . $from;
    $headers2 = "From:" . $to;
    mail($to,$subject,$message); ?>
    <div class="messagesent">
    <?php
    echo "Mail Sent. Thank you " . $first_name . ", we will contact you shortly."; ?> </div><?php
	
    }
?>

<!-------------------------------->

<div class="form-container">

<div style="font-family:cambria; width:100%;text-align:center;margin:5% 0;color:#5DBDAB;font-size:25px; "> I'm interested. Call me!</div>
<form action="" method="post" onSubmit="return validation()" class="order-form">

  
  <div>
    <label class="desc" id="title1" for="Field1">Full Name</label>
    <div>
      <input id="Field1" name="first_name" type="text" class="field text fn" value="" size="8" tabindex="1">
    </div>
  </div>
    
  <div>
    <label class="desc" id="title3" for="Field3">
      Email
    </label>
    <div>
      <input id="email" name="email" type="email" spellcheck="false" value="" maxlength="255" tabindex="3"> 
   </div>
  </div>
  
  <div>
    <label class="desc" id="title7" for="Field7">
      PHONE
    </label>
    <div>
      <input id="mobilenumber" name="mobile_number" type="text" spellcheck="false" value="" maxlength="255" tabindex="3"> 
   </div>
  </div>
    
  <div>
  
    <label class="desc" id="title4" for="Field4">
      Message
    </label>
  
    <div>
      <textarea id="Field4" name="message" spellcheck="true" rows="4" cols="20" tabindex="4"></textarea>
    </div>
  </div>
    
  <div>
    <fieldset>
    
      <label id="title5" class="desc">
        REGIME
      </label>
      
      <div>
      	<input id="radioDefault_5" name="Field5" type="hidden" value="">
      	<div >
      		<input id="Field5_0" name="regime" type="radio" value="Seeker" tabindex="5" checked="checked">
      		<label class="choice" for="Field5_0">SEEKER <small>[1 Day ]</small></label>
      	</div>
        <div >
        	<input id="Field5_1" name="regime" type="radio" value="Sage" tabindex="6">
        	<label class="choice" for="Field5_1">SAGE <small>[ 3 Days]</small></label>
        </div>
        <div >
        	<input id="Field5_2" name="regime" type="radio" value="Nirvana" tabindex="7">
        	<label class="choice" for="Field5_2">NIRVANA <small>[ 6 Days]</small></label>
        </div>
      </div>
    </fieldset>
  </div>
  
  <div>
		<div>
  		<input id="saveForm" name="submit" type="submit" value="REACH ME">
    </div>
	</div>
  
</form>
</div>

<div class="contentsd" style="text-align:right;">




<div class="order-image" style="float:left;text-align:left;width:40%;">
<img width="570" height="402" src="images/CONTACT.png"> 
</div>



<div style="clear:both;"> </div>
</div>



<div class="clear"> </div>
</div><!--parent-->
<!--<h4 class="dlvruy-logsdf" style="margin: -55px 0 0 180px;">Serving Hyderabad</h4>-->





<?php include "includes/footer.php" ?>

  





</div>

<!-- All Cms and home page block  -->



<!-- MIDDLE CONTENT END -->  

<script type='text/javascript'>
function validation() {

var email	         =	document.getElementById('email').value;
var mobilenumber     =	document.getElementById('mobilenumber').value;

if(email=="")
	      {
	        alert("Enter Email ID");
		    document.getElementById('email').focus();
		    return false;
		  }
		  else
		  {
		   var re = /\S+@\S+\.\S+/;
    		if(!re.test(email))
			{
			alert("Enter Valid Email");
			return false;
		  	}
		  }
		  
		       if(mobilenumber=="")
	   {
	       alert("Please Enter Mobile Number");
		   document.getElementById('mobilenumber').focus();
		   return false; 
		}
		 else
		  {
		   var re = /^[0-9\b]+$/
		   if(!re.test(mobilenumber))
			{
			alert("Mobile Number Must be Numbers Only");
			return false;
		  	}
		  }
		  
	if (mobilenumber.length < 10)
	        {
                alert("Mobile Number should have miniumum 10 Numbers");
				 document.getElementById('mobilenumber').focus();
				 return false;
		   }
}

</script>


<script type="text/javascript">



jQuery(function(){



// The height of the content block when it's not expanded



var adjustheight = 140;



// The "more" link text



var moreText = "Read More...";



// The "less" link text



var lessText = "Read Less...";







// Sets the .more-block div to the specified height and hides any content that overflows



jQuery(".more-less .more-block").css('height', adjustheight).css('overflow', 'hidden').css('margin-bottom','20px');







// The section added to the bottom of the "more-less" div



//$(".more-less").append('<p class="continued">[&hellip;]</p><a href="#" class="adjust"></a>');







jQuery(".more-less").append('<a href="#" class="adjust continued"></a>');







jQuery("a.adjust").text(moreText);







jQuery(".adjust").toggle(function() {



		jQuery(this).parents("div:first").find(".more-block").css('height', 'auto').css('overflow', 'visible');



		// Hide the [...] when expanded



		jQuery(this).parents("div:first").find("p.continued").css('display', 'none');



		jQuery(this).text(lessText);



	}, function() {



		jQuery(this).parents("div:first").find(".more-block").css('height', adjustheight).css('overflow', 'hidden');



		jQuery(this).parents("div:first").find("p.continued").css('display', 'block');



		jQuery(this).text(moreText);



});



});







</script>



 <!-- Instragram Recent Posted Pictures Dispalying Block -->

		<!-- Instragram Recent Posted Pictures Dispalying Block END -->		





        

	

         <div class="clear"> </div>





	

</body>

</html>