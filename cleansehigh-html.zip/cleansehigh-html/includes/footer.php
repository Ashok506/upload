<footer>
 
<div class="press-images container-fluid">



			<div class="col-md-2">
				<img src="images/01.png" class="img-responsive">
					
			</div>
			<div class="col-md-2">
					<img src="images/02.png" class="img-responsive">
			</div>
			
			<div class="col-md-2">
				<img src="images/03.png" class="img-responsive">
				
			</div>
			<div class="col-md-2 ">
					<img src="images/04.png" class="img-responsive">
					
			</div>
			
			<div class="col-md-2">
					<img src="images/05.png" class="img-responsive">
				
			</div>
			

</div>

<div class="brdr-btm">

</div>


<p class="ftr-ont"> Be Social. Stay informed. </p>

<div class="social-icons">

<a href="http://www.facebook.com/pages/Cleanse-High/135553573287000?fref=ts" target="_blank" title="Like Facebook"><img src="images/facebook.png" alt="facebook"></a>
           <a class="ig-b- ig-b-48" href="http://instagram.com/cleansehigh?ref=badge" target="_blank" title="Join Instagram"><img src="images/instagram.png" alt="instagram"></a>
            <a href="mailto:detox@cleansehigh.com" title="Share by Email"><img src="images/mail.png" alt="email"></a>
</div>
<div class="footr-mtd">
    <div class="footr-mnu">
    	<ul>
        	<li> <a href="#"> Terms </a>  </li> 
            <li> <a href="#" style="line-height: 1.6;"> Privacy </a> </li>
        </ul>
    </div>

    <div class="footr-cpy">
    	© 2016 CLEANSEHIGH
    </div>
    
    <div class="footr-brnd">
    	BRAND DESIGN BY <a href="http://www.creatlivestudios.com/" target="_blank">CREATLIVE STUDIOS</a>
    </div>
    

</div>
<p class="flip">Procedure</p>
<div id="opncls" style="background-color: #FFEDCA;">

<div class="proced">




	<!--<h3 class="mn-hdngt"> It's Simple  </h3>-->
    <div class="badge badge1">
		  <h6 class="crvdt crvdt1">It's Simple</h6>
	</div>

	<div class="pd-1" style="margin-left: 15%;">
    	<img src="images/ftr-cal.png" class="pd-img1" />
	    <img src="images/ftr-phn.png" class="pd-img2" />
    </div>
    
    	<div class="pd-brdr">
        	
            
            <!--<p class="frstd-txtbtm">
            	Order Here <br />
                8008698686<br />
            </p>-->
            
        </div>
    
	<div class="pd-1">
		<img src="images/ftr-juice.png" class="pd-img3" />
        <img src="images/ftr-truck.png" class="pd-img4" />
    </div>
    
    	<div class="pd-brdr">
        
       
        
        </div>

	<div class="pd-1">
    	<img src="images/ftr-boxd.png" class="pd-img5" />
        <img src="images/ftr-nmbr.png" class="pd-img6" />
    </div>
</div>

	<div class="main-mdh">
    	
        <div class="cnt-img">
        
        	<p class="frstd-txt">
            	<span class="spn-fr">Plan ahead<br />
                your detox day</span>
                <!--<span style="font-size: 30px;width: 67%; margin:0 auto;line-height: 1;">Order Here 8008698686</span>-->
            </p>
        
        <li  class="tryupp" style="margin-top: -9%; margin-left: -31%;">
<button type="button" class="btn btn-info btn-lg" style="padding: 5px 16px; background-color: #5DBDAB; border-color: #5DBDAB;">
            <a style="padding:0 23px; color:#fff;" href="order.php"><span>Order</span></a></button>
        </li>
        
        
        
        </div>
        
        <div class="cnt-img">
        	 <p class="frstd-txt" style="margin-left:2%;">
            	<span class="spn-fr">We freshly<br />
                press your elixirs & </span>
                <span class="ftrimdill" style="font-size: 30px;width: 67%; margin:0 auto;line-height: 1;">DELIVER TO YOUR DOOR STEP</span>
            </p>
            
        </div>
        
        <div class="cnt-img">
        
        	<p class="frstd-txt" style="margin-left:28%;">
            	<span class="spn-fr">Once you receive,<br />
                refrigerate</span>
                <!--<span>DELIVER TO YOUR DOOR STEP</span>-->
               <span class="ftrimdill" style="font-size: 30px;width: 90%; margin:0 auto;line-height: 1;">Consume by Number & Time</span>
            </p>

        </div>
        
    </div>

</div>


<!--<p class="ftr-ont"> Procedure </p>-->







<div class="clear"> </div>
</footer>



<style>
.flip {
    margin: 0px;
    padding: 5px;
    text-align: center;
    background: #5DBDAB;
    border: solid 1px #5DBDAB;
    position: absolute;
    float: right;
    color: #ffffff;
    margin-top: 0%;
    z-index: 9999;
    font-size: 20px;
    font-family: contentheading;
    cursor: pointer;
    border-radius: 10px;
    padding: 8px 8px;
    letter-spacing: 3px;
}

#opncls{
	display:none;
    bottom: 14px;
	position:absolute;
	width:98%;
	}

</style>

<script type="text/javascript">
	$(document).ready(function() {
		$(".flip").click(function() {
			$("#opncls").slideToggle("slow");
		});
	});
</script>