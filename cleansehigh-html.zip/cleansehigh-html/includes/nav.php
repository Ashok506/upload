<a href="#menu" id="toggle"><span></span></a>

<div id="menu">
  <nav class="nav">
    <ul class="txt-uc txt-cr">
        <li>
            <a href="#">LEARN</a>
            <ul class="ldrt">
                <li> <a href="whydetox.php"> Why Detox </a></li>
                <li> <a href="benefits.php"> Benefits </a> </li>
                <li> <a href="our-goodness.php"> Our Goodness </a> </li>
                <li> <a id="bnf" href="care.php"> Care </a> </li>
                <li class="last-brdr"> <a href="faqs.php"> Faq's </a> </li>
	        </ul>
        </li>
        <li><a href="regimes.php" style="padding:0 66px;">REGIMES</a></li>
        <li id="mrgty"><a href="#">WE</a>
            <ul class="ldrt" style="margin-top:-4px;">
               <li><a href="our-story.php">OUR STORY</a></li>
               <li><a href="philosophy.php">PHILOSOPHY</a></li>
               <li class="last-brdr"><a href="testimonials.php">Testimonials</a></li>
            </ul>
        </li>
        
        <li  class="tryupp" style="margin-top: -2%; margin-left:-5%;">
<a style="padding:0 23px; color:#fff;" href="order.php">
<button type="button" class="btn btn-info btn-lg" style="padding: 5px 16px; background-color: #5DBDAB; border-color: #5DBDAB;">
<span>Order</span></button></a>
        </li>
        
        <!--<li  class="tryupp" style="margin-top: -2%; margin-left:-5%;">
<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal" style="padding: 5px 16px; background-color: #5DBDAB; border-color: #5DBDAB;">
            <a style="padding:0 23px; color:#fff;"><span>Gift</span></a></button>
        </li>-->
    </ul>
</nav>
</div>

<a href="index.php">
	<div class="brand"><br />
 </div>
</a>

<nav id="nav-prfct" class="nav">
    <ul class="txt-uc txt-cr">
        <li>
            <a href="#">LEARN</a>
            <ul class="ldrt">
                <li> <a href="whydetox.php"> Why Detox </a></li>
                <li> <a href="benefits.php"> Benefits </a> </li>
                <li> <a href="our-goodness.php"> Our Goodness </a> </li>
                <li> <a id="bnf" href="care.php"> Care </a> </li>
                <li class="last-brdr"> <a href="faqs.php"> Faq's </a> </li>
	        </ul>
        </li>
        <li><a href="regimes.php" style="padding:0 66px;">REGIMES</a></li>
        <li id="mrgty"><a href="#">WE</a>
            <ul class="ldrt" style="margin-top:-4px;">
               <li><a href="our-story.php">OUR STORY</a></li>
               <li><a href="philosophy.php">PHILOSOPHY</a></li>
               <li class="last-brdr"><a href="testimonials.php">Testimonials</a></li>
            </ul>
        </li>
        <!--<li id="btngh55"><a href="order.php" class="guidebox order-btnh" style="color:#fff;"><span style="background-color: #5DBDAB; border: 1px dashed #5DBDAB;">ORDER</span></a></li>-->
        
        <li  class="tryupp" style="margin-top: -2%; margin-left:-5%;">
<a style="padding:0 23px; color:#fff;" href="order.php">
<button type="button" class="btn btn-info btn-lg" style="padding: 5px 41px; background-color: #5DBDAB; border-color: #5DBDAB; color:#ffffff; margin-left: -23px;">
<span>Order</span></button></a>
</li>
        
        
        <!--<li  class="tryupp" style="margin-top: -2%; margin-left:1%;">
<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal" style="padding: 5px 16px; background-color: #5DBDAB; border-color: #5DBDAB; outline:none;">
            <a style="padding:0 23px; color:#fff;"><span>Gift</span></a></button>
        </li>-->
    </ul>
</nav>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
  <script>
  
  var theToggle = document.getElementById('toggle');

// based on Todd Motto functions
// http://toddmotto.com/labs/reusable-js/

// hasClass
function hasClass(elem, className) {
	return new RegExp(' ' + className + ' ').test(' ' + elem.className + ' ');
}
// addClass
function addClass(elem, className) {
    if (!hasClass(elem, className)) {
    	elem.className += ' ' + className;
    }
}
// removeClass
function removeClass(elem, className) {
	var newClass = ' ' + elem.className.replace( /[\t\r\n]/g, ' ') + ' ';
	if (hasClass(elem, className)) {
        while (newClass.indexOf(' ' + className + ' ') >= 0 ) {
            newClass = newClass.replace(' ' + className + ' ', ' ');
        }
        elem.className = newClass.replace(/^\s+|\s+$/g, '');
    }
}
// toggleClass
function toggleClass(elem, className) {
	var newClass = ' ' + elem.className.replace( /[\t\r\n]/g, " " ) + ' ';
    if (hasClass(elem, className)) {
        while (newClass.indexOf(" " + className + " ") >= 0 ) {
            newClass = newClass.replace( " " + className + " " , " " );
        }
        elem.className = newClass.replace(/^\s+|\s+$/g, '');
    } else {
        elem.className += ' ' + className;
    }
}

theToggle.onclick = function() {
   toggleClass(this, 'on');
   return false;
}
  </script>
  
  
<script>


function validation() {

var name	        = document.getElementById('name').value;
var email	    = document.getElementById('email').value;
var youremail	    = document.getElementById('youremail').value;

  
if(name=="")
{
   alert("Enter Recepient name");
   document.getElementById('name').focus();
   return false;
}
else
 {
  var re = /^[a-zA-Z ]{2,30}$/
  if(!re.test(name))
{
alert("Enter Alphabets Only");
return false;
 	}
 }
 
  
    if(email=="")
     {
       alert("Enter Email ID");
   document.getElementById('email').focus();
   return false;
 }
 else
 {
  var re = /\S+@\S+\.\S+/;
   	if(!re.test(email))
{
alert("Enter Valid Email");
return false;
 	}
 }
 
 
   if(youremail=="")
     {
       alert("Enter Email ID");
   document.getElementById('youremail').focus();
   return false;
 }
 else
 {
  var re = /\S+@\S+\.\S+/;
   	if(!re.test(youremail))
{
alert("Enter Valid Email");
return false;
 	}
 }
 
}

</script>



<script>
$(".close").on("click",function(){
  $("form div").removeClass("error");
  $("form label").removeClass("error");
  $("form")[0].reset();
});

</script>


