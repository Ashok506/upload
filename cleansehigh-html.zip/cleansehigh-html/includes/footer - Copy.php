



<footer>

 
<div class="press-images">
<ul>
<li><a href="#"><img src="images/press-logos/grazia.png"></a></li>
<li style="width: 16%; margin-top: 0%;">
<a href="http://www.thehindu.com/features/metroplus/fitness/a-juice-detox-might-just-set-you-back-on-the-right-track-to-fitness-believes-sindura-borra-of-cleanse-high/article6373370.ece" target="_blank"><img src="images/press-logos/hindu.png"></a></li>

<li style="margin-top: 1.5%;"><a href="http://www.thealternative.in/lifestyle/cleanse-high-healthier-fasting-and-feasting/" target="_blank"><img src="images/press-logos/alternative.png"></a></li>
<li style="width: 14%;margin-top: -1.5%;"><a href="#"><img src="images/press-logos/toi.png"></a></li>
<li><a href="http://archives.deccanchronicle.com/130927/lifestyle-fashionbeauty/article/a%E2%80%88detox-%E2%80%98package%E2%80%99-cleanse-your-body" target="_balnk"><img src="images/press-logos/dc.png"></a></li>


</ul>

</div>

<div class="brdr-btm">

</div>


<p class="ftr-ont"> Be Social. Stay informed. </p>

<div class="social-icons">

<a href="http://www.facebook.com/pages/Cleanse-High/135553573287000?fref=ts" target="_blank" title="Like Facebook"><img src="images/facebook.png" alt="facebook"></a>
           <a class="ig-b- ig-b-48" href="http://instagram.com/cleansehigh?ref=badge" target="_blank" title="Join Instagram"><img src="images/instagram.png" alt="instagram"></a>
            <a href="mailto:detox@cleansehigh.com" title="Share by Email"><img src="images/mail.png" alt="email"></a>
</div>

<div class="demo-frame">
                <div id="demo-with-image">
                    <a class="expander collapsed" href="#"></a>
                    <div class="content" style="display: none;">
                        
                        
                        <div class="proced">

	<!--<h3 class="mn-hdngt"> It's Simple  </h3>-->
    <div class="badge badge1">
		  <h6 class="crvdt crvdt1">It's Simple</h6>
	</div>

	<div class="pd-1" style="margin-left: 15%;">
    	<img src="images/ftr-cal.png" class="pd-img1" />
	    <img src="images/ftr-phn.png" class="pd-img2" />
    </div>
    
    	<div class="pd-brdr">

        </div>
    
	<div class="pd-1">
		<img src="images/ftr-juice.png" class="pd-img3" />
        <img src="images/ftr-truck.png" class="pd-img4" />
    </div>
    
    	<div class="pd-brdr">
        
       
        
        </div>

	<div class="pd-1">
    	<img src="images/ftr-boxd.png" class="pd-img5" />
        <img src="images/ftr-nmbr.png" class="pd-img6" />
    </div>
</div>

	<div class="main-mdh">
    	
        <div class="cnt-img">
        
        	<p class="frstd-txt">
            	<span class="spn-fr">Plan ahead<br />
                your detox day</span>
            </p>
        
        <li  class="tryupp" style="margin-top: -9%; margin-left: -31%;">
<button type="button" class="btn btn-info btn-lg" style="padding: 5px 16px; background-color: #5DBDAB; border-color: #5DBDAB;">
            <a style="padding:0 23px; color:#fff;" href="order.php"><span>Order</span></a></button>
        </li>
        
        
        
        </div>
        
        <div class="cnt-img">
        	 <p class="frstd-txt" style="margin-left:2%;">
            	<span class="spn-fr">We freshly<br />
                press your elixirs & </span>
                <span class="ftrimdill" style="font-size: 30px;width: 67%; margin:0 auto;line-height: 1;">DELIVER TO YOUR DOOR STEP</span>
            </p>
        </div>
        
        <div class="cnt-img">
        
        	<p class="frstd-txt" style="margin-left:28%;">
            	<span class="spn-fr">Once you receive,<br />
                refrigerate</span>
                <!--<span>DELIVER TO YOUR DOOR STEP</span>-->
               <span class="ftrimdill" style="font-size: 30px;width: 90%; margin:0 auto;line-height: 1;">Consume by Number & Time</span>
            </p>

        </div>
        
    </div>



<div class="footr-mtd">
    <div class="footr-mnu">
    	<ul>
        	<li> <a href="#"> Terms </a>  </li> 
            <li> <a href="#" style="line-height: 1.6;"> Privacy </a> </li>
        </ul>
    </div>

    <div class="footr-cpy">
    	© 2016 CLEANSEHIGH
    </div>
    
    <div class="footr-brnd">
    	BRAND DESIGN BY <a href="http://www.creatlivestudios.com/" target="_blank">CREATLIVE STUDIOS</a>
    </div>
    

</div>
                        
                        
                    </div>
                </div>
            </div>



<!--<p class="ftr-ont"> Procedure </p>-->







<div class="clear"> </div>
</footer>


<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
<script src="http://css-tricks.com/examples/BlurredText/js/jquery.lettering.js"></script>
<script>
	$(function() {
		$(".crvdt").lettering();
	});
</script>



<script type="text/javascript" src="http://sylvain-hamel.github.io/simple-expand/javascripts/google-code-prettify/prettify.js"></script>
<script type="text/javascript" src="http://sylvain-hamel.github.io/simple-expand/javascripts/simple-expand.js"></script>
<script type="text/javascript">
       $(function () {
           $('.expander').simpleexpand();
           prettyPrint();
       });
</script>

<style>
            
            .content {display:none;}
            
#demo-with-image .expander.expanded {
    padding-left: 13px;
    background-position: left center;
    background-repeat: no-repeat;
    background-image: url(images/top-arwwww.png);
    float: right;
    margin-top: -62px;
    padding: 2%;
    padding-right: 3%;
    position: absolute;
    padding-top: 3%;
    background-size: 60%;
    right: 0;
    bottom: 3%;
}
        
            #demo-with-image .expander.collapsed {
                padding-left: 13px;
                background-position: left center;
                background-repeat: no-repeat;
                background-image: url(images/dwn-arwww.png);
				float:right;
				margin-top:-62px;
				padding:2%;
			    padding-right: 3%;
				padding-top:3%;
			    background-size: 60%;
            }        


                   
        
        </style>