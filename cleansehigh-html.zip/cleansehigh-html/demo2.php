<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">

<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=8" />
<meta http-equiv="X-UA-Compatible" content="IE=9" />
<meta name="google-site-verification" content="google3552560da7870e25" />
<meta name="keywords" content="detox program, health detox, diet plan for detoxification, 1-day detox, Detoxify The Body, 3-day detox, Nourish Pack, Favourites Pack, Cleanse, Cleanse High, health, super foods,raw, cold pressed, organic greens, fresh vegetables" />
<meta name="rights" content="CleanseHigh.com" />
<meta name="robots" content="index, follow" />
<meta name="description" content="Choose your detox diet plan from a range of 1 day, 3 day, 6 day, or create your own set of favorite detox juices. Each detox regime is designed to kick-start process of cleansing and detoxification. - CleanseHigh India" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Detox Diet Plan : Seeker, Sage, Nirvana Regimes from CleanseHigh India</title>
<link rel="image_src" href="http://cleansehigh.com/images/buddy-high.png" / >
<!-- Metatags & Description & Titles adding into dynamically at all pages -->
<!--<link rel="stylesheet" href="css/bootstrap.min.css">-->
<link rel="icon" type="image/x-icon" href="http://www.cleansehigh.com/images/favicon.png">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/venky.css" type="text/css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
 <meta name="viewport" content="width=device-width, initial-scale=1">

</head><body>
<div class="wrapper">
  <!-- Top Header -->
  <header>
    <div class="header-authentication txt-rt"> </div>
   		  <a href="index.php">
			<div class="brand"><br />
          </div>
     </a>
	<nav id="nav-prfct" class="nav">
    <ul class="txt-uc txt-cr">
        <li>
            <a href="#">LEARN</a>
            <ul class="ldrt">
                <li> <a href="whydetox.php"> Why Detox </a></li>
                <li> <a href="benefits.php"> Benefits </a> </li>
                <li> <a href="our-goodness.php"> Our Goodness </a> </li>
                <li> <a id="bnf" href="care.php"> Care </a> </li>
                <li class="last-brdr"> <a href="faqs.php"> Faq's </a> </li>
	        </ul>
        </li>
        <li><a href="regimes.php" style="padding:0 66px;">REGIMES</a></li>
        <li id="mrgty"><a href="#">WE</a>
            <ul class="ldrt" style="margin-top:-4px;">
               <li><a href="our-story.php">OUR STORY</a></li>
               <li><a href="philosophy.php">PHILOSOPHY</a></li>
               <li class="last-brdr"><a href="testimonials.php">Testimonials</a></li>
            </ul>
        </li>
       <li  class="tryupp" style="margin-top: -2%;">
<a style="color:#fff;" href="order.php">
<button type="button"  style="padding: 5px 41px; background-color: #5DBDAB; border-color: #5DBDAB; color:#ffffff;">
<span>Order</span></button></a></li>

    </ul>
</nav>
  </header>
  <!-- All Cms and home page block  -->
 
  <div class="wrap pull-left wrap1">
 <div class="container">


<form class="form-inline">
  <div class="form-group">
   <label>1</label>
    <input type="email" class="form-control" id="email" size="20px" placeholder="Email address">
  </div>
  <div class="form-group">
   
    <input type="password" class="form-control" id="pwd" placeholder="Password">
  </div>


  <div class="form-group">
    
    <input type="submit" class="form-control btn btn-warning" value="LOGIN">
  </div>


  <input type="submit" class="form-control btn btn-warning" value="REGISTER">
</form>
		<hr  style="border-top: dotted 1px;">

<div class="row">
  <div class="col-6 col-md-4">
    
<div class="well">
 
</div>
<p>During this extended fast your body<br> removes dead, dying and deseased cells</p>
<p>View</p>
<p><strong>Price:</strong>Rs 1260 /-</p>
<p><strong>Detox Date:</strong><input type="text" name=""></p>
<p><strong>Qty:</strong><input type="text" name="" value="1"></p>
<input type="submit" class ="btn btn-warning"value ="ADD TO CART">



    </div>

 
  <div class="col-6 col-md-4 pannel">

  <div class="well">
 
</div>

<div class="pannel">
<p>During this extended fast your body<br> removes dead, dying and deseased cells</p>
<p>View</p>
<p><strong>Price:</strong>Rs 1260 /-</p>
<p><strong>Detox Date:</strong><input type="text" name=""></p>
<p><strong>Qty:</strong><input type="text" name="" value="1"></p>
<input type="submit" class ="btn btn-warning"value ="ADD TO CART">
</div>



</div>
  <div class="col-6 col-md-4">
    
<div class="well">
 
</div>
<p>During this extended fast your body<br> removes dead, dying and deseased cells</p>
<p>View</p>
<p><strong>Price:</strong>Rs 1260 /-</p>
<p><strong>Detox Date:</strong><input type="text" name=""></p>
<p><strong>Qty:</strong><input type="text" name="" value="1"></p>
<input type="submit" class ="btn btn-warning"value ="ADD TO CART">


  </div>

    <hr  style="border-top: dotted 1px;">
</div>

	
  </div>,
  
  
  





			  

	
	 
	 
	 
	 


 

  
  
<div class="clearfix" ></div>
  
  <!-- All Cms and home page block  -->
  <!-- MIDDLE CONTENT END -->
  
  
<?php include'includes/footer.php' ?>



  
  <!-- Footer End -->
  <div class="clear"> </div>
</div>
</body>
</html>